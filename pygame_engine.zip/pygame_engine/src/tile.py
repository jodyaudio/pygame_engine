from static_entity import StaticEntity


class Tile(StaticEntity):
    def __init__(self):
        super(Tile, self).__init__()
