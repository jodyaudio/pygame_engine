import pygame
import gfx
from controller import Controller
from splash_screen import SplashScreen
import constants as c
import os
import ctypes


def initialize_game():
    """Initializes all necessary modules and sets the opening window to be centered.
    Note that the mixer is an odd module and must have the pre_init and init functions called in this specific way
    in order to prevent an audio delay in pygame. Not sure why this is :/"""
    os.environ['SDL_VIDEO_CENTERED'] = '1'          # Opens game window in the center of display
    pygame.mixer.pre_init(44100, -16, 2, 512)       # Configure the pygame mixer
    pygame.init()                                   # Initialize PyGame module
    pygame.mixer.init()                             # Initialize mixer


def get_display():
    """Returns a pygame display for native, scaled, or fullscreen mode.
    The gfx.load_graphics function is called at this point due to it needing to be executed after a display has
    been created."""

    if c.FULLSCREEN:
        monitor_resolution = get_resolution()  # TODO
        display = pygame.display.set_mode(c.DISPLAY_SIZE, pygame.FULLSCREEN | pygame.HWACCEL | pygame.DOUBLEBUF)
    else:
        display = pygame.display.set_mode(c.DISPLAY_SIZE)
    gfx.load_graphics(c.DIR_GRAPHICS, c.COLOR_KEY)    # Graphics must be loaded after display set_mode and not before
    return display


def get_clock():
    """Returns a clock for maintaining the games frame rate. 60 FPS should be used for this game."""
    return pygame.time.Clock()


def get_game_states():
    """Returns a dictionary that contains all possible game state classes.
    Please store a pointer to the class itself instead of calling the class' constructor method at this point. Doing
    it this way, will save memory resources. No need to create an instance of every game state at this point since
    only 1 state is actually used at a time."""
    game_states = {c.SPLASH_SCREEN: SplashScreen}
    return game_states


def get_controller(display, clock, game_states, starting_state):
    """Return a controller object for running the mainloop of the game. See controller.py file for information on
    how the Controller class works. It is by far the most important part of understanding this program!"""
    return Controller(display, clock, game_states, starting_state)


def get_resolution():
    """Returns the user's monitor's resolution in tuple form."""
    user32 = ctypes.windll.user32
    resolution = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    return resolution
