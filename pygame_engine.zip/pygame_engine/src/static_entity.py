import pygame
import gfx
import constants as c
import ultracolors as color


class StaticEntity(pygame.sprite.Sprite):
    def __init__(self):
        super(StaticEntity, self).__init__()
        self.image = pygame.Surface(c.MED_TILE_SIZE)
        self.color = color.GREEN
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.pos_x = 0.0
        self.pos_y = 0.0
        self.vel_x = 0.0
        self.vel_y = 0.0

    def update(self):
        self.update_pos()
        self.debug()

    def update_pos(self):
        self.pos_x += self.vel_x
        self.pos_y += self.vel_y
        self.rect.x += int(self.pos_x)
        self.rect.y += int(self.pos_y)

    #####################################################
    ################# Setters / Getters #################
    #####################################################

    def set_pos(self, xy):
        self.rect.x = xy[0]
        self.rect.y = xy[1]

    def get_pos(self):
        return self.rect.x, self.rect.y

    def set_image(self, img):
        self.image = img
        self.rect = self.image.get_rect()

    def get_image(self):
        return self.image

    def debug(self):
        pass