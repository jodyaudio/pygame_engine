from static_entity import StaticEntity
import gfx


class SplashLogo(StaticEntity):
    def __init__(self):
        super(SplashLogo, self).__init__()
        self.image = gfx.graphics['mega_man_walk_01']
