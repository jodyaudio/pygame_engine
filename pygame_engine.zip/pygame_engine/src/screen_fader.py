import pygame
from dynamic_entity import DynamicEntity
import constants as c
import ultracolors as color


class ScreenFader(DynamicEntity):
    def __init__(self):
        super(ScreenFader, self).__init__()
        self.set_animated(False)
        self.image = pygame.Surface(c.NATIVE_SIZE)
        self.color = color.PURPLE
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.alpha_max = 255.0
        self.alpha_min = 0.0
        self.alpha = self.alpha_max
        self.set_alpha(self.alpha)
        self.alpha_decrement = 5.0
        self.alpha_increment = 5.0
        self.add_state("FADE_IN", self.state_fade_in)
        self.add_state("PAUSE", self.state_pause)
        self.add_state("FADE_OUT", self.state_fade_out)
        self.set_state("PAUSE")

    def state_fade_in(self):
        if self.states.init:
            self.set_alpha(self.alpha_max)
            self.states.set_init(False)

        if self.alpha >= self.alpha_min:
            self.alpha -= self.alpha_decrement
            self.set_alpha(self.alpha)
        else:
            self.set_alpha(self.alpha_min)
            self.set_state("PAUSE")

    def state_fade_out(self):
        if self.states.init:
            self.set_alpha(self.alpha_min)
            self.states.set_init(False)

        if self.alpha <= self.alpha_max:
            self.alpha += self.alpha_increment
            self.set_alpha(self.alpha)
        else:
            self.set_alpha(self.alpha_max)
            self.set_state("PAUSE")

    def state_pause(self):
        if self.states.init:
            self.states.set_init(False)

    #####################################################
    ################# Setters / Getters #################
    #####################################################

    def set_alpha(self, value):
        self.alpha = value
        self.image.set_alpha(int(self.alpha))

    def get_alpha(self):
        return self.alpha

    def set_color(self, new_color):
        self.color = new_color
        self.image.fill(self.color)

    def get_color(self):
        return self.color

    def set_increment(self, value):
        self.alpha_increment = value

    def set_decrement(self, value):
        self.alpha_decrement = value
