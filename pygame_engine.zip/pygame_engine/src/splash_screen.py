from game_state import GameState
from splash_logo import SplashLogo
import constants as c
from player import Player


class SplashScreen(GameState):
    def __init__(self):
        super(SplashScreen, self).__init__()
        self.screen_fader.set_state("FADE_OUT")