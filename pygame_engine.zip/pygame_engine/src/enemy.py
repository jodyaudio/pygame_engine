from dynamic_entity import DynamicEntity


class Enemy(DynamicEntity):
    def __init__(self):
        super(Enemy, self).__init__()
