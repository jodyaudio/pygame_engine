from game_state import GameState


class Level(GameState):
    def __init__(self, tile_map, tile_sheet):
        super(Level, self).__init__()
