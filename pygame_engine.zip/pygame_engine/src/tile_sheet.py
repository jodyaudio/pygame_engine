class TileSheet:
    def __init__(self):
        pass