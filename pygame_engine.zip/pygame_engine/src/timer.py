class TimerGroup:
    def __init__(self):
        self.timers = {}

    def add_timer(self, name, duration, loop=False, active=False):
        self.timers[name] = Timer(name, duration, loop, active)

    def update(self):
        for name, timer in self.timers.items():
            if timer.active:
                timer.update()


class Timer:
    def __init__(self, name, duration, loop, active):
        self.name = name
        self.duration = duration
        self.current_value = self.duration
        self.loop = loop
        self.active = active

    def update(self):
        if self.current_value == 0:
            self.current_value = self.duration
            if not self.loop:
                self.active = False
        else:
            self.current_value -= 1